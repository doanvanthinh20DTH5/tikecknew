//
//  detailticket.swift
//  planeticket2
//
//  Created by DoanThinh on 5/12/23.
//

import SwiftUI

struct detailticket: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct detailticket_Previews: PreviewProvider {
    static var previews: some View {
        detailticket()
    }
}
