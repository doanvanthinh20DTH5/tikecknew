//
//  LoginGmail.swift
//  planeticket2
//
//  Created by DoanThinh on 5/15/23.
//

import SwiftUI

struct LoginGmail: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct LoginGmail_Previews: PreviewProvider {
    static var previews: some View {
        LoginGmail()
    }
}
