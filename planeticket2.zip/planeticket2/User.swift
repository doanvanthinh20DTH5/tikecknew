//
//  User.swift
//  planeticket2
//
//  Created by DoanThinh on 5/17/23.
//

import SwiftUI

struct User: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct User_Previews: PreviewProvider {
    static var previews: some View {
        User()
    }
}
